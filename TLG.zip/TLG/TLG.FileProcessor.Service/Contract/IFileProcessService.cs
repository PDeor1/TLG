﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace TLG.FileProcessor.Service.Contract
{
    public interface IFileProcessService
    {
        (int, int,string,string,int) ProcessFile(string fileName);
    }
}
