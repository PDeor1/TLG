﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using TLG.FileProcessor.Service.Contract;
using System.Data.SqlClient;
using System.Threading.Tasks;
using TGL.FileProcessor.Utilities;
using TLG.FileProcessor.Repositories;
using TLG.FileProcessor.Repositories.Contract;

namespace TLG.FileProcessor.Service
{
    public class FileProcessService : IFileProcessService
    {
        private List<string> _lstMissingData = new List<string>();
        private List<string> _lstInvalidFields = new List<string>();
        private readonly IFileProcessRepository _repository;
        private int rowsInserted = 0;


        public FileProcessService(IFileProcessRepository repository)
        {
            _repository = repository;
        }

        public (int,int,string,string, int) ProcessFile(string fileName)
        {
            IEnumerable<DataTable> dataTables = _repository.ReadFileData(fileName);

            foreach (DataTable tbl in dataTables)
            {
                List<string> missingData;
                List<string> invalidFields;
                int countRows = 0;

                if (tbl.Rows.Count > 0)
                {
                    /* Call file process repo service */
                    countRows = _repository.SaveFileData(tbl);
                }

                /* Get the data upload result */
                rowsInserted += countRows;
                missingData = _repository.GetMissingData();
                invalidFields = _repository.GetInvalidFields();
                _lstMissingData.AddRange(missingData);
                _lstInvalidFields.AddRange(invalidFields);

            }

            var misingDataFile =_repository.SaveMissingDataReportToFile(_lstMissingData,fileName.Split('.')[0] + "_" + "MissingData");
            var invalidDataFile = _repository.SaveInvalidDataReportToFile(_lstInvalidFields, fileName.Split('.')[0] + "_" + "InvalidData");

            return (_lstMissingData.Count, _lstInvalidFields.Count, misingDataFile, invalidDataFile, rowsInserted);
        }
    }
}
