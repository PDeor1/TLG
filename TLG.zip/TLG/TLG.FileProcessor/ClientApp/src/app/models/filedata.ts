export class Filedata {
  missingData?: string;
  invalidInputFields?: string;
  missingFieldFile?: string;
  invalidFieldFile?: string;
  numberOfRecordsInserted?: string;
}
