import { Component, OnInit, EventEmitter, ElementRef, Input } from '@angular/core';
import { FileUploadService } from '../services/file-upload.service';
import { HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
  @Input() public disabled: boolean;
  isLoading: boolean = false;
  showFileDetails: boolean = false;

  numRecordsInserted: string;
  countMissingData: string;
  countInvalidData: string;
  fileMissingData: string;
  fileInvalidData: string;

  fileMetaData: FormData;
  fileName: File;

  constructor(private fileService: FileUploadService) { }



  ngOnInit() {
  }

  onFileSelected(ev) {
    this.showFileDetails = false;
    this.fileName = ev[0];
  }
  onUploadClicked() {
    this.fileMetaData = new FormData();

    this.fileMetaData.append('files', this.fileName, this.fileName.name);

    this.isLoading = true;

    this.fileService.uploadFileNew(this.fileName).subscribe(
      data => {
        if (data) {
          switch (data.type) {
            case HttpEventType.Response:
              this.isLoading = false;
              this.numRecordsInserted = data.body.numberOfRecordsInserted;
              this.countMissingData = data.body.missingData;
              this.countInvalidData = data.body.invalidInputFields;
              this.fileMissingData = "file:///" + data.body.missingFieldFile;
              this.fileInvalidData = "file:///" + data.body.invalidFieldFile;
              this.showFileDetails = true;
              break;

          }
        }
      },
      error => {
        this.isLoading = false;
      }
    );


  };
}




