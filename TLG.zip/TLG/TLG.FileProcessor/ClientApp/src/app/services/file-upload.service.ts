import { Injectable } from '@angular/core';
import { StartupService } from './startup.service';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { UserData } from '../../models/user-data';
import { map, catchError } from 'rxjs/operators';
import { Filedata } from '../models/filedata';

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  private svc: string = 'https://localhost:44375/api/';
  private baseApiUrl: string;
  private apiUploadUrl: string;
  errorHandlerService: any;

  constructor(
    private http: HttpClient,
  ) {
    this.baseApiUrl = 'https://localhost:44375/api/';
    this.apiUploadUrl = this.baseApiUrl + 'upload';
  }

  uploadFile(param): Promise<any> {
    return this.http.post(this.svc + 'FileUpload', param).toPromise().then(resp => resp);
  }
  uploadFileNew(file: Blob): Observable<HttpEvent<Filedata>> {
    const formData = new FormData();
    formData.append('file', file);

    return this.http.request(new HttpRequest(
      'POST',
      this.apiUploadUrl,
      formData,
      {
        reportProgress: true,
        responseType:'json'
      }));
  }

}
