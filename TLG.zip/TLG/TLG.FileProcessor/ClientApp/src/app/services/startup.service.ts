import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Settings } from '../models/settings';

@Injectable({
  providedIn: 'root'
})
export class StartupService {

  private _settings: Settings;

  constructor(private http: HttpClient) {

    this._settings = null;
  }

  // This is the method you want to call at bootstrap
  // Important: It should return a Promise
  load(): Promise<Settings> {

    this._settings = null;

    return this.http.get<Settings>('/settings')
      .toPromise()
      .then(data => {

        this._settings = data;
        return this._settings;
      });
  }

  get settings(): Settings {
    return this._settings;
  }
}
