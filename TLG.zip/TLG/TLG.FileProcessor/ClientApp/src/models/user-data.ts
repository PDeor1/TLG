export class UserData {
  numberOfRecords: string;
}

