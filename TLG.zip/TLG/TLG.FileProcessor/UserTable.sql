﻿USE [TGL_UserDB]
GO

/****** Object:  Table [dbo].[UserDetails]    Script Date: 07-11-2020 15:39:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserDetails](
	[SchemeId] [varchar](50) NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[Email] [varchar](50) NULL,
	[Mobile] [varchar](50) NULL
) ON [PRIMARY]
GO