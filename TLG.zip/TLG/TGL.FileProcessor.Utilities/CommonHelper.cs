﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGL.FileProcessor.Utilities
{
    public class CommonHelper
    {
        public static string DbConnection = Environment.GetEnvironmentVariable("ConnectionString");
        public static int DataUploadLimit = Convert.ToInt32(Environment.GetEnvironmentVariable("DataUploadLimit"));
    }
}
