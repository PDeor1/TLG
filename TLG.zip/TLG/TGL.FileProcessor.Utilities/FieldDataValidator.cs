﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Text.RegularExpressions;
using System.IO;

namespace TGL.FileProcessor.Utilities
{
    public class FieldDataValidator
    {
        static string emailPattern = @"^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$";
        static string mobilePattern = @"^[0-9]{10}$";
        /* Can add more regex */

        public static bool IsEmailValid(string email)
        {
            return Regex.IsMatch(email, emailPattern);
        }
        public static bool IsMobileValid(string mobile)
        {
            return Regex.IsMatch(mobile, mobilePattern);
        }

        public static string ValidateInput(IList<string> lstInput)
        {
            StringBuilder strBuilder = new StringBuilder();
            
            if(!IsEmailValid(lstInput[3]))
            {
                strBuilder.Append("  Email : " + lstInput[3]);
            }
            if (!IsMobileValid(lstInput[4]))
            {
                strBuilder.Append("  Mobile : " + lstInput[4]);
            }
            return strBuilder.ToString();
        }
    }
}
