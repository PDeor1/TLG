﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using TLG.FileProcessor.Service;
using TLG.FileProcessor.Service.Contract;

namespace TLG.FileProcessor.API.Controllers
{
    [AllowAnonymous]
    [Route("api")]
    [ApiController]
    public class FileUploadController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IFileProcessService _fileProcessorService;
        public FileUploadController(IConfiguration configuration, IFileProcessService fileProcessorService)
        {
            _configuration = configuration;
            _fileProcessorService = fileProcessorService;
        }
        private string Extensions { get; } = "csv";

        [HttpPost]
        [Route("upload")]
        [RequestFormLimits(MultipartBodyLengthLimit = 552428800)]
        [RequestSizeLimit(552428800)]
        public async Task<IActionResult> Upload(IFormFile file)
        {

            bool isValid = true;
            int missingFileData = 0;
            int invalidFields = 0;
            string missingDataFile = string.Empty;
            string invalidDataFile = string.Empty;
            int numberOfRecordsInserted = 0;
            List<string> allowedExtensions = Extensions.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();

            string filePath = _configuration["FilePath:Name"];
            isValid = allowedExtensions.Any(y => file.FileName.EndsWith(y));

            if (!isValid)
            {
                return Ok(new { responseCode = 400, responseMessage = "Invalid file type" });
            }

            if (file.Length > 0)
            {
                var fileName = filePath + file.FileName;

                using (var stream = new FileStream(fileName, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                (missingFileData, invalidFields, missingDataFile, invalidDataFile, numberOfRecordsInserted) = _fileProcessorService.ProcessFile(fileName);

            }
            else
            {
                return Ok(new { responseCode = 400, responseMessage = "No files to upload" });
            }

            if (numberOfRecordsInserted > 0 && missingFileData == 0 && invalidFields == 0)
                return Ok(new { responseCode = 200, responseMessage = "File data saved successfully", missingData = missingFileData, invalidInputFields = invalidFields, numberOfRecordsInserted });
            else
                return Ok(new { responseCode = 200, responseMessage = "File data saved successfully, some data missing or invalid", missingData = missingFileData, invalidInputFields = invalidFields, missingFieldFile = missingDataFile, invalidFieldFile = invalidDataFile, numberOfRecordsInserted });





        }



    }
}
