﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace TLG.FileProcessor.Repositories.Contract
{
    public interface IFileProcessRepository
    {
        IEnumerable<DataTable> ReadFileData(string fileName);
        int SaveFileData(DataTable table);
        List<string> GetMissingData();
        List<string> GetInvalidFields();
        string SaveMissingDataReportToFile(List<string> lstMissingData, string fileName);
        string SaveInvalidDataReportToFile(List<string> lstInvalidFields, string fileName);
    }
}
