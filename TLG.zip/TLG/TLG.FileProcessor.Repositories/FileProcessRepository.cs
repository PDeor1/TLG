﻿using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Threading.Tasks;
using TLG.FileProcessor.Repositories.Contract;
using TGL.FileProcessor.Utilities;
using System;

namespace TLG.FileProcessor.Repositories
{
    public class FileProcessRepository : IFileProcessRepository
    {
        private List<string> _lstMissingData = new List<string>();
        private List<string> _lstInvalidFields = new List<string>();
        private string _missingDataFile = string.Empty;
        private string _invalidDataFile = string.Empty;
        private int _currIteration = 0;

        public IEnumerable<DataTable> ReadFileData(string fileName)
        {
            int chunkRowCount = 0;
            DataTable chunkDataTable = CreateUserDataTable();

            using (var sr = new StreamReader(fileName))
            {
                string line = null;
                while ((line = sr.ReadLine()) != null)
                {
                    if(chunkRowCount == 0)
                    {
                        _lstMissingData = new List<string>();
                        _lstInvalidFields = new List<string>();
                        chunkDataTable = CreateUserDataTable();
                    }

                    AddRow(chunkDataTable, line, chunkRowCount);
                    chunkRowCount++;

                    if (chunkRowCount == CommonHelper.DataUploadLimit)
                    {
                        chunkRowCount = 0;
                        yield return chunkDataTable;
                        chunkDataTable = null;
                        _currIteration++;
                    }
                }
            }

            if (null != chunkDataTable)
                yield return chunkDataTable;
        }

        public int SaveFileData(DataTable table)
        {
            try
            {
                using (var bulkCopy = new SqlBulkCopy(CommonHelper.DbConnection, SqlBulkCopyOptions.Default))
                {
                    bulkCopy.BulkCopyTimeout = 0;
                    GetColumnMappings(bulkCopy);
                    Task.Run(async () => { await bulkCopy.WriteToServerAsync(table); }).Wait();
                }
            }
            catch (Exception ex)
            {
                /* Log exception */
                return  0;
            }

            return table.Rows.Count;

        }

        private static void GetColumnMappings(SqlBulkCopy bulkCopy)
        {
            bulkCopy.DestinationTableName = "UserDetails";
            bulkCopy.ColumnMappings.Add("SchemeId", "SchemeId");
            bulkCopy.ColumnMappings.Add("FirstName", "FirstName");
            bulkCopy.ColumnMappings.Add("LastName", "LastName");
            bulkCopy.ColumnMappings.Add("Email", "Email");
            bulkCopy.ColumnMappings.Add("Mobile", "Mobile");
        }

        private DataTable CreateUserDataTable()
        {
            var dataTable = new DataTable("UserDetails");
            dataTable.Columns.Add(new DataColumn("SchemeId", typeof(string)));
            dataTable.Columns.Add(new DataColumn("FirstName", typeof(string)));
            dataTable.Columns.Add(new DataColumn("LastName", typeof(string)));
            dataTable.Columns.Add(new DataColumn("Email", typeof(string)));
            dataTable.Columns.Add(new DataColumn("Mobile", typeof(string)));
            return dataTable;
        }

        private void AddRow(DataTable dataTable, string line, int chunkRowCount)
        {
            var lineNumber = (_currIteration * CommonHelper.DataUploadLimit) + chunkRowCount;
            DataRow newRow = dataTable.NewRow();
            IList<string> fieldData = Split(line);
            if (fieldData != null && fieldData.Count == 5)
            {
                var invalidInput = FieldDataValidator.ValidateInput(fieldData);
                if (!string.IsNullOrEmpty( invalidInput))
                {
                    _lstInvalidFields.Add("Invalid input fields - " + lineNumber + " : " + invalidInput);
                    return;
                }

                for (int columnIndex = 0; columnIndex < dataTable.Columns.Count; columnIndex++)
                {
                    newRow[columnIndex] = fieldData[columnIndex];
                }
                dataTable.Rows.Add(newRow);
            }
            else
            {
                
                _lstMissingData.Add("Missing data at line number - " + lineNumber.ToString());
            }
        }



        private IList<string> Split(string input)
        {
            var dataList = new List<string>();
            foreach (string column in input.Split('\t'))
            {
                dataList.Add(column);
            }
            return dataList;
        }

        public List<string> GetMissingData()
        {
            return _lstMissingData;
        }

        public List<string> GetInvalidFields()
        {
            return _lstInvalidFields;
        }

        public string MissingDataFileName()
        {
            return _missingDataFile;
        }

        public string InvalidDataFileName()
        {
            return _invalidDataFile;
        }

        public string SaveMissingDataReportToFile(List<string> lstMissingData,string fileName)
        {
            fileName += ".txt";
            FileStream fParameter = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            StreamWriter streamParameter = new StreamWriter(fParameter);
            streamParameter.BaseStream.Seek(0, SeekOrigin.End);
            foreach (var data in lstMissingData)
            {
                streamParameter.WriteLine(data);
            }
           
            streamParameter.Flush();
            streamParameter.Close();

            return fileName;
        }

        public string SaveInvalidDataReportToFile(List<string> lstInvalidField,string fileName)
        {
            fileName += ".txt";
            FileStream fParameter = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            StreamWriter streamWriter = new StreamWriter(fParameter);
            streamWriter.BaseStream.Seek(0, SeekOrigin.End);
            streamWriter.Write(lstInvalidField);
            foreach (var field in lstInvalidField)
            {
                streamWriter.WriteLine(field);
            }
            streamWriter.Flush();
            streamWriter.Close();

            return fileName;
        }
    }
}
